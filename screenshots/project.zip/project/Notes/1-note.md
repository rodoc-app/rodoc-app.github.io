Tohle je jednoduchá poznámka.
